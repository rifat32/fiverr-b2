"use strict";
(() => {
var exports = {};
exports.id = 204;
exports.ids = [204];
exports.modules = {

/***/ 4511:
/***/ ((module) => {

module.exports = require("next-iron-session");

/***/ }),

/***/ 453:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ sendMagicLink)
});

;// CONCATENATED MODULE: external "nodemailer"
const external_nodemailer_namespaceObject = require("nodemailer");
var external_nodemailer_default = /*#__PURE__*/__webpack_require__.n(external_nodemailer_namespaceObject);
// EXTERNAL MODULE: external "next-iron-session"
var external_next_iron_session_ = __webpack_require__(4511);
// EXTERNAL MODULE: ./utils/links.ts
var links = __webpack_require__(4290);
;// CONCATENATED MODULE: ./pages/api/sendMagicLink.ts



async function handler(req, res) {
    try {
        const { email  } = req.body;
        const transporter = external_nodemailer_default().createTransport({
            host: "smtp-relay.sendinblue.com",
            port: 587,
            secure: false,
            auth: {
                user: "nyl9488.yln@gmail.com",
                pass: "xsmtpsib-b35186d265440c5f5793a2e572b7f6eae17367cbdf13436fa9c06168dacc20f2-6z1c5ZXYk2DKLm8M"
            }
        });
        const token = Math.random().toString(36).substr(2, 8);
        req.session.set("token", token);
        await req.session.save();
        const protocol = req.headers["x-forwarded-proto"] || "http";
        const host = req.headers["x-forwarded-host"] || req.headers.host;
        // construct the app URL
        const appUrl = `${protocol}://${host}`;
        const info = await transporter.sendMail({
            from: "Your App Name <nyl9488.yln@gmail.com>",
            to: email,
            subject: "Magic Login Link",
            html: `
        <p>Hello!</p>
        <p>You recently requested a magic login link for Your App Name.</p>
        <p>Click the link below to login:</p>
        <a href="${appUrl}/api/verifyMagicLink?token=${token}&&email=${email}">
        ${appUrl}/api/verifyMagicLink?token=${token}&&email=${email}
        </a>
        <p>Note: This link will expire in 24 hours.</p>
      `
        });
        console.log("Email sent: ", info);
        const savedToken = req.session.get("token");
        res.status(200).json({
            message: "Magic login link sent to email address",
            savedToken,
            token
        });
    } catch (error) {
        console.error("Error sending magic link: ", error);
        res.status(500).json({
            message: "Error sending magic link"
        });
    }
}
/* harmony default export */ const sendMagicLink = ((0,external_next_iron_session_.withIronSession)(handler, {
    password: links/* IronSessionPassword */.J,
    cookieName: "my_session_cookie_name",
    cookieOptions: {
        secure: true
    }
}));


/***/ }),

/***/ 4290:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "J": () => (/* binding */ IronSessionPassword)
/* harmony export */ });
/* unused harmony export AppUrl */
const IronSessionPassword = "my_secret_passwordsssssagggsegaetgaegaegaWEGWSEgsgwWSegAWEGGSEGSEGSEG";
const AppUrl = "http://localhost:3000";


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(453));
module.exports = __webpack_exports__;

})();
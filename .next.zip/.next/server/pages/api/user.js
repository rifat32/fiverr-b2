"use strict";
(() => {
var exports = {};
exports.id = 541;
exports.ids = [541];
exports.modules = {

/***/ 4511:
/***/ ((module) => {

module.exports = require("next-iron-session");

/***/ }),

/***/ 7414:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ prismadb)
});

;// CONCATENATED MODULE: external "@prisma/client"
const client_namespaceObject = require("@prisma/client");
;// CONCATENATED MODULE: ./lib/prismadb.ts

const client = globalThis.prisma || new client_namespaceObject.PrismaClient();
if (false) {}
/* harmony default export */ const prismadb = (client);


/***/ }),

/***/ 6566:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_iron_session__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4511);
/* harmony import */ var next_iron_session__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_iron_session__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_prismadb__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7414);
/* harmony import */ var _utils_links__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4290);



async function handler(req, res) {
    try {
        const { email , token  } = req.query;
        let userSession = req.session.get("user");
        if (userSession) {
            userSession = JSON.parse(userSession);
        }
        if (!userSession || !userSession.email) {
            console.log("User not logged in");
            return res.status(401).json("Login to upload.");
        }
        const user = await _lib_prismadb__WEBPACK_IMPORTED_MODULE_1__/* ["default"].user.findUnique */ .Z.user.findUnique({
            where: {
                email: userSession.email
            }
        });
        res.status(200).json({
            message: "ok",
            user: user
        });
    } catch (error) {
        console.error("Error sending magic link: ", error);
        res.status(500).json({
            message: "Error sending magic link"
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_iron_session__WEBPACK_IMPORTED_MODULE_0__.withIronSession)(handler, {
    password: _utils_links__WEBPACK_IMPORTED_MODULE_2__/* .IronSessionPassword */ .J,
    cookieName: "my_session_cookie_name",
    cookieOptions: {
        secure: true
    }
}));


/***/ }),

/***/ 4290:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "J": () => (/* binding */ IronSessionPassword)
/* harmony export */ });
/* unused harmony export AppUrl */
const IronSessionPassword = "my_secret_passwordsssssagggsegaetgaegaegaWEGWSEgsgwWSegAWEGGSEGSEGSEG";
const AppUrl = "http://localhost:3000";


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(6566));
module.exports = __webpack_exports__;

})();
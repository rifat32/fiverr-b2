"use strict";
(() => {
var exports = {};
exports.id = 459;
exports.ids = [459];
exports.modules = {

/***/ 4511:
/***/ ((module) => {

module.exports = require("next-iron-session");

/***/ }),

/***/ 7414:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ prismadb)
});

;// CONCATENATED MODULE: external "@prisma/client"
const client_namespaceObject = require("@prisma/client");
;// CONCATENATED MODULE: ./lib/prismadb.ts

const client = globalThis.prisma || new client_namespaceObject.PrismaClient();
if (false) {}
/* harmony default export */ const prismadb = (client);


/***/ }),

/***/ 586:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ remaining)
});

// EXTERNAL MODULE: ./lib/prismadb.ts + 1 modules
var prismadb = __webpack_require__(7414);
;// CONCATENATED MODULE: external "request-ip"
const external_request_ip_namespaceObject = require("request-ip");
var external_request_ip_default = /*#__PURE__*/__webpack_require__.n(external_request_ip_namespaceObject);
// EXTERNAL MODULE: external "next-iron-session"
var external_next_iron_session_ = __webpack_require__(4511);
// EXTERNAL MODULE: ./utils/links.ts
var links = __webpack_require__(4290);
;// CONCATENATED MODULE: ./pages/api/remaining.ts




async function handler(req, res) {
    // Check if user is logged in
    let userSession = req.session.get("user");
    if (userSession) {
        userSession = JSON.parse(userSession);
    }
    if (!userSession || !userSession.email) {
        console.log("User not logged in");
        return res.status(401).json("Login to upload.");
    }
    // const userCreated = await prisma.user.create({
    //   data: {
    //     name:"Rifat",
    //     email:"rifatbilalphilips@gmail.com",
    //   },
    // })
    // console.log('User created:', userCreated)
    // const session = await getServerSession(req, res, authOptions);
    // if (!session || !session.user) {
    //   console.log("User not logged in");
    //   return res.status(401).json("Login to upload.");
    // }
    // Query the database by email to get the number of generations left
    const user = await prismadb/* default.user.findUnique */.Z.user.findUnique({
        where: {
            email: userSession.email
        },
        select: {
            credits: true,
            location: true
        }
    });
    if (!user) {
        const userCreated = await prismadb/* default.user.create */.Z.user.create({
            data: {
                name: "Manually created User",
                email: userSession.email
            }
        });
    }
    if (!user?.location) {
        const ip = external_request_ip_default().getClientIp(req);
        const location = await fetch(`http://api.ipstack.com/${ip}?access_key=${process.env.IPSTACK_API_KEY}`).then((res)=>res.json());
        await prismadb/* default.user.update */.Z.user.update({
            where: {
                email: userSession.email
            },
            data: {
                location: location.country_code
            }
        });
    }
    return res.status(200).json({
        remainingGenerations: user?.credits
    });
}
/* harmony default export */ const remaining = ((0,external_next_iron_session_.withIronSession)(handler, {
    password: links/* IronSessionPassword */.J,
    cookieName: "my_session_cookie_name",
    cookieOptions: {
        secure: true
    }
}));


/***/ }),

/***/ 4290:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "J": () => (/* binding */ IronSessionPassword)
/* harmony export */ });
/* unused harmony export AppUrl */
const IronSessionPassword = "my_secret_passwordsssssagggsegaetgaegaegaWEGWSEgsgwWSegAWEGGSEGSEGSEG";
const AppUrl = "http://localhost:3000";


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(586));
module.exports = __webpack_exports__;

})();
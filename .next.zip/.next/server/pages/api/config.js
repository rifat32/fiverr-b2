"use strict";
(() => {
var exports = {};
exports.id = 589;
exports.ids = [589];
exports.modules = {

/***/ 206:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "apiConfig": () => (/* binding */ apiConfig),
/* harmony export */   "apiHandler": () => (/* binding */ apiHandler)
/* harmony export */ });
const apiConfig = {
    api: {
        bodyParser: {
            sizeLimit: "10mb"
        }
    }
};
const apiHandler = (handler)=>async (req, res)=>{
        // Only allow certain file types to be uploaded
        if (req.headers["content-type"]?.includes("multipart/form-data")) {
            const contentType = req.headers["content-type"];
            if (!contentType.includes("image/png") && !contentType.includes("image/jpeg") && !contentType.includes("image/jpg")) {
                res.status(400).json({
                    error: "Invalid file type"
                });
                return;
            }
        }
        await handler(req, res);
    };


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(206));
module.exports = __webpack_exports__;

})();
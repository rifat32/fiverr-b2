"use strict";
(() => {
var exports = {};
exports.id = 550;
exports.ids = [550];
exports.modules = {

/***/ 4217:
/***/ ((module) => {

module.exports = require("micro");

/***/ }),

/***/ 2799:
/***/ ((module) => {

module.exports = require("micro-cors");

/***/ }),

/***/ 6090:
/***/ ((module) => {

module.exports = import("stripe");;

/***/ }),

/***/ 7414:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ prismadb)
});

;// CONCATENATED MODULE: external "@prisma/client"
const client_namespaceObject = require("@prisma/client");
;// CONCATENATED MODULE: ./lib/prismadb.ts

const client = globalThis.prisma || new client_namespaceObject.PrismaClient();
if (false) {}
/* harmony default export */ const prismadb = (client);


/***/ }),

/***/ 1840:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _lib_prismadb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7414);
/* harmony import */ var stripe__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6090);
/* harmony import */ var micro__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4217);
/* harmony import */ var micro__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(micro__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var micro_cors__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2799);
/* harmony import */ var micro_cors__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(micro_cors__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([stripe__WEBPACK_IMPORTED_MODULE_1__]);
stripe__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const stripe = new stripe__WEBPACK_IMPORTED_MODULE_1__["default"](process.env.STRIPE_SECRET_KEY, {
    apiVersion: "2022-11-15"
});
const config = {
    api: {
        bodyParser: false
    }
};
const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET || "";
const cors = micro_cors__WEBPACK_IMPORTED_MODULE_3___default()({
    allowMethods: [
        "POST",
        "HEAD"
    ]
});
const webhookHandler = async (req, res)=>{
    if (req.method === "POST") {
        const buf = await (0,micro__WEBPACK_IMPORTED_MODULE_2__.buffer)(req);
        const sig = req.headers["stripe-signature"];
        let event;
        try {
            event = stripe.webhooks.constructEvent(buf.toString(), sig, webhookSecret);
        } catch (err) {
            const errorMessage = err instanceof Error ? err.message : "Unknown error";
            // On error, log and return the error message.
            if (err instanceof Error) console.log(err);
            console.log(`❌ Error message: ${errorMessage}`);
            res.status(400).send(`Webhook Error: ${errorMessage}`);
            return;
        }
        // Successfully constructed event.
        console.log("✅ Success:", event.id);
        // Cast event data to Stripe object.
        if (event.type === "payment_intent.succeeded" || event.type === "checkout.session.completed") {
            const paymentIntent = event.data.object;
            console.log(`💰 PaymentIntent: ${JSON.stringify(paymentIntent)}`);
            // @ts-ignore
            const userEmail = paymentIntent.customer_details.email;
            let creditAmount = 0;
            // @ts-ignore
            switch(paymentIntent.amount_subtotal){
                case 500:
                case 1000:
                    creditAmount = 20;
                    break;
                case 1900:
                case 3000:
                    creditAmount = 100;
                    break;
                case 3500:
                case 5000:
                    creditAmount = 250;
                    break;
                case 7000:
                case 7900:
                case 10000:
                    creditAmount = 750;
                    break;
            }
            await _lib_prismadb__WEBPACK_IMPORTED_MODULE_0__/* ["default"].user.update */ .Z.user.update({
                where: {
                    email: userEmail
                },
                data: {
                    credits: {
                        increment: creditAmount
                    }
                }
            });
            await _lib_prismadb__WEBPACK_IMPORTED_MODULE_0__/* ["default"].purchase.create */ .Z.purchase.create({
                data: {
                    creditAmount: creditAmount,
                    user: {
                        connect: {
                            email: userEmail
                        }
                    }
                }
            });
        } else if (event.type === "payment_intent.payment_failed") {
            const paymentIntent = event.data.object;
            console.log(`❌ Payment failed: ${paymentIntent.last_payment_error?.message}`);
        } else if (event.type === "charge.succeeded") {
            const charge = event.data.object;
            console.log(`💵 Charge id: ${charge.id}`);
        } else {
            console.warn(`🤷‍♀️ Unhandled event type: ${event.type}`);
        }
        // Return a response to acknowledge receipt of the event. Upgraded.
        res.json({
            received: true
        });
    } else {
        res.setHeader("Allow", "POST");
        res.status(405).end("Method Not Allowed");
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (cors(webhookHandler));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(1840));
module.exports = __webpack_exports__;

})();
"use strict";
(() => {
var exports = {};
exports.id = 565;
exports.ids = [565,748];
exports.modules = {

/***/ 7414:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ prismadb)
});

;// CONCATENATED MODULE: external "@prisma/client"
const client_namespaceObject = require("@prisma/client");
;// CONCATENATED MODULE: ./lib/prismadb.ts

const client = globalThis.prisma || new client_namespaceObject.PrismaClient();
if (false) {}
/* harmony default export */ const prismadb = (client);


/***/ }),

/***/ 5366:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "authOptions": () => (/* binding */ authOptions),
  "default": () => (/* binding */ _nextauth_)
});

;// CONCATENATED MODULE: external "next-auth"
const external_next_auth_namespaceObject = require("next-auth");
var external_next_auth_default = /*#__PURE__*/__webpack_require__.n(external_next_auth_namespaceObject);
;// CONCATENATED MODULE: external "next-auth/providers/google"
const google_namespaceObject = require("next-auth/providers/google");
var google_default = /*#__PURE__*/__webpack_require__.n(google_namespaceObject);
;// CONCATENATED MODULE: external "@next-auth/prisma-adapter"
const prisma_adapter_namespaceObject = require("@next-auth/prisma-adapter");
// EXTERNAL MODULE: ./lib/prismadb.ts + 1 modules
var prismadb = __webpack_require__(7414);
;// CONCATENATED MODULE: ./pages/api/auth/[...nextauth].ts




const authOptions = {
    adapter: (0,prisma_adapter_namespaceObject.PrismaAdapter)(prismadb/* default */.Z),
    providers: [
        google_default()({
            clientId: process.env.GOOGLE_CLIENT_ID || "",
            clientSecret: process.env.GOOGLE_CLIENT_SECRET || ""
        })
    ]
};
/* harmony default export */ const _nextauth_ = (external_next_auth_default()({
    ...authOptions
}));


/***/ }),

/***/ 3015:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

;// CONCATENATED MODULE: external "next-auth/next"
const next_namespaceObject = require("next-auth/next");
// EXTERNAL MODULE: ./pages/api/auth/[...nextauth].ts + 3 modules
var _nextauth_ = __webpack_require__(5366);
// EXTERNAL MODULE: ./lib/prismadb.ts + 1 modules
var prismadb = __webpack_require__(7414);
;// CONCATENATED MODULE: ./pages/api/generate.ts



async function handler(req, res) {
    // Check if user is logged in
    const session = await (0,next_namespaceObject.getServerSession)(req, res, _nextauth_.authOptions);
    if (!session || !session.user) {
        return res.status(500).json("Login to upload.");
    }
    // Get user from DB
    const user = await prismadb/* default.user.findUnique */.Z.user.findUnique({
        where: {
            email: session.user.email
        },
        select: {
            credits: true
        }
    });
    // Check if user has any credits left
    if (user?.credits === 0) {
        return res.status(400).json(`You have no generations left`);
    }
    // If they have credits, decrease their credits by one and continue
    await prismadb/* default.user.update */.Z.user.update({
        where: {
            email: session.user.email
        },
        data: {
            credits: {
                decrement: 1
            }
        }
    });
    try {
        const { imageUrl , theme , room  } = req.body;
        const prompt = room === "Gaming Room" ? "a video gaming room" : `a ${theme.toLowerCase()} ${room.toLowerCase()}`;
        // POST request to Replicate to start the image restoration generation process
        let startResponse = await fetch("https://api.replicate.com/v1/predictions", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: "Token " + process.env.REPLICATE_API_KEY
            },
            body: JSON.stringify({
                version: "d55b9f2dcfb156089686b8f767776d5b61b007187a4e1e611881818098100fbb",
                input: {
                    image: imageUrl,
                    structure: "hough",
                    prompt: prompt,
                    scale: 9,
                    a_prompt: "best quality, photo from Pinterest, interior, cinematic photo, ultra-detailed, ultra-realistic, award-winning, interior design, natural lighting",
                    n_prompt: "longbody, lowres, bad anatomy, bad hands, missing fingers, extra digit, fewer digits, cropped, worst quality, low quality"
                }
            })
        });
        let jsonStartResponse = await startResponse.json();
        let endpointUrl = jsonStartResponse.urls.get;
        const originalImage = jsonStartResponse.input.image;
        const roomId = jsonStartResponse.id;
        // GET request to get the status of the image restoration process & return the result when it's ready
        let generatedImage = null;
        while(!generatedImage){
            // Loop in 1s intervals until the alt text is ready
            let finalResponse = await fetch(endpointUrl, {
                method: "GET",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: "Token " + process.env.REPLICATE_API_KEY
                }
            });
            let jsonFinalResponse = await finalResponse.json();
            if (jsonFinalResponse.status === "succeeded") {
                generatedImage = jsonFinalResponse.output[0];
            } else if (jsonFinalResponse.status === "failed") {
                break;
            } else {
                await new Promise((resolve)=>setTimeout(resolve, 1000));
            }
        }
        if (generatedImage) {
            await prismadb/* default.room.create */.Z.room.create({
                data: {
                    replicateId: roomId,
                    user: {
                        connect: {
                            email: session.user.email
                        }
                    },
                    inputImage: originalImage,
                    outputImage: generatedImage,
                    prompt: prompt
                }
            });
        } else {
            throw new Error("Failed to restore image");
        }
        res.status(200).json(generatedImage ? {
            original: originalImage,
            generated: generatedImage,
            id: roomId
        } : "Failed to restore image");
    } catch (error) {
        // Increment their credit if something went wrong
        await prismadb/* default.user.update */.Z.user.update({
            where: {
                email: session.user.email
            },
            data: {
                credits: {
                    increment: 1
                }
            }
        });
        console.error(error);
        res.status(500).json("Failed to restore image");
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3015));
module.exports = __webpack_exports__;

})();
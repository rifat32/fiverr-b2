"use strict";
(() => {
var exports = {};
exports.id = 26;
exports.ids = [26];
exports.modules = {

/***/ 3185:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Dashboard),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./components/Header.tsx
var Header = __webpack_require__(9852);
// EXTERNAL MODULE: external "next-auth/react"
var react_ = __webpack_require__(1649);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./components/Footer.tsx
var Footer = __webpack_require__(932);
;// CONCATENATED MODULE: external "@prisma/client"
const client_namespaceObject = require("@prisma/client");
;// CONCATENATED MODULE: ./lib/prismadb.ts

const client = globalThis.prisma || new client_namespaceObject.PrismaClient();
if (false) {}
/* harmony default export */ const prismadb = (client);

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/RoomGenerator.tsx


function RoomGeneration({ original , generated  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "flex flex-col space-y-10 mt-4 mb-4 border px-8 pb-8 pt-2 border-gray-600 rounded-xl",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex sm:space-x-8 sm:flex-row flex-col pb-5",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            className: "mb-1 font-medium text-lg",
                            children: "Original"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            alt: "Original room",
                            src: original,
                            className: "rounded-2xl h-full",
                            width: 400,
                            height: 400
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "sm:mt-0 mt-8",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                            className: "mb-1 font-medium text-lg",
                            children: "Generated"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            alt: "Generated room",
                            width: 400,
                            height: 400,
                            src: generated,
                            className: "rounded-2xl h-full sm:mt-0 mt-2"
                        })
                    ]
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: external "next-auth"
const external_next_auth_namespaceObject = require("next-auth");
var external_next_auth_default = /*#__PURE__*/__webpack_require__.n(external_next_auth_namespaceObject);
;// CONCATENATED MODULE: external "next-auth/providers/google"
const google_namespaceObject = require("next-auth/providers/google");
var google_default = /*#__PURE__*/__webpack_require__.n(google_namespaceObject);
;// CONCATENATED MODULE: external "@next-auth/prisma-adapter"
const prisma_adapter_namespaceObject = require("@next-auth/prisma-adapter");
;// CONCATENATED MODULE: ./pages/api/auth/[...nextauth].ts




const authOptions = {
    adapter: (0,prisma_adapter_namespaceObject.PrismaAdapter)(prismadb),
    providers: [
        google_default()({
            clientId: process.env.GOOGLE_CLIENT_ID || "",
            clientSecret: process.env.GOOGLE_CLIENT_SECRET || ""
        })
    ]
};
/* harmony default export */ const _nextauth_ = (external_next_auth_default()({
    ...authOptions
}));

;// CONCATENATED MODULE: ./pages/dashboard.tsx










function Dashboard({ rooms  }) {
    const { data: session  } = (0,react_.useSession)();
    let user = localStorage.getItem("user");
    if (user) {
        user = JSON.parse(user);
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex max-w-6xl mx-auto flex-col items-center justify-center py-2 min-h-screen",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((head_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx("title", {
                    children: "DecorAI Dashboard"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Header/* default */.Z, {
                photo: user?.image || undefined,
                email: user?.email || undefined
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
                className: "flex flex-1 w-full flex-col items-center justify-center text-center px-4 mt-12 sm:mb-0 mb-8",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                        className: "mx-auto max-w-4xl font-display text-4xl font-bold tracking-normal text-slate-100 sm:text-6xl mb-5",
                        children: [
                            "View your ",
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "text-blue-600",
                                children: "room"
                            }),
                            " generations"
                        ]
                    }),
                    rooms.length === 0 ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: "text-gray-300",
                        children: [
                            "You have no room generations. Generate one",
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/dream",
                                className: "text-blue-600 underline underline-offset-2",
                                children: "here"
                            })
                        ]
                    }) : /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-gray-300",
                        children: "Browse through your previous room generations below. Any feedback? Email decorai.xyz@gmail.com"
                    }),
                    rooms.map((room)=>/*#__PURE__*/ jsx_runtime_.jsx(RoomGeneration, {
                            original: room.inputImage,
                            generated: room.outputImage
                        }))
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Footer/* default */.Z, {})
        ]
    });
}
async function getServerSideProps(ctx) {
    const session = await (0,external_next_auth_namespaceObject.getServerSession)(ctx.req, ctx.res, authOptions);
    const req = ctx.req;
    const protocol = req.headers["x-forwarded-proto"] || "http";
    const host = req.headers["x-forwarded-host"] || req.headers.host;
    const baseUrl = `${protocol}://${host}`;
    const response = await fetch(`${baseUrl}/api/user`);
    const data = await response.json();
    if (!data?.user) {
        return {
            props: {
                rooms: []
            }
        };
    }
    let rooms = await prismadb.room.findMany({
        where: {
            user: {
                email: data?.user.email
            }
        },
        select: {
            inputImage: true,
            outputImage: true
        }
    });
    return {
        props: {
            rooms
        }
    };
}


/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [636,61,415], () => (__webpack_exec__(3185)));
module.exports = __webpack_exports__;

})();